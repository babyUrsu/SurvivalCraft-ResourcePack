// Full-glyph blue/white fluid motion with crossed, time-varying flow fields.
// effectParams.x = animation speed
// effectParams.y = turbulence strength
void applyMidnightGhoulWaterEffect(vec2 uv,
                                   vec4 baseColor,
                                   vec4 blueColor,
                                   vec4 whiteColor,
                                   vec4 effectParams,
                                   vec3 glyphT0, vec3 glyphT1, vec3 glyphT2, vec3 glyphT3,
                                   float gameTime,
                                   sampler2D tex,
                                   out vec4 result) {
    float alpha = texture(tex, uv).a;
    if (alpha < 0.1) discard;

    vec2 uvMin, uvMax;
    calculateUVBounds(glyphT0, glyphT1, glyphT2, glyphT3, uvMin, uvMax);
    if (uvMax.x < uvMin.x || uvMax.y < uvMin.y) {
        uvMin = vec2(0.0);
        uvMax = vec2(1.0);
    }

    vec2 size = max(uvMax - uvMin, vec2(0.0001));
    vec2 p = clamp((uv - uvMin) / size, 0.0, 1.0);
    float speed = effectParams.x;
    float turbulence = effectParams.y;

    // Atlas position gives adjacent glyphs different flow phases.
    float seed = dot(uvMin, vec2(127.1, 311.7));
    float t = gameTime * speed * 1800.0 + seed;
    vec2 q = p * vec2(6.0, 5.0);

    // Crossed, warped waves make the currents curl and drift in several directions.
    float flowA = sin(q.x + sin(q.y * 1.37 - t * 0.73) * 1.7 + t * 0.61);
    float flowB = cos(q.y * 1.11 + sin(q.x * 1.29 + t * 0.57) * 1.5 - t * 0.82);
    float flowC = sin((q.x - q.y) * 0.78 + sin((q.x + q.y) * 0.63 + t * 0.41));
    float field = (flowA * 0.42 + flowB * 0.38 + flowC * 0.20) * turbulence;

    // Blue fills most of the glyph; narrow moving ridges form white water streaks.
    float currents = smoothstep(-0.48, 0.52, field);
    float ridge = 1.0 - smoothstep(0.025, 0.16, abs(field - 0.08));
    float whiteMix = clamp(0.08 + currents * 0.27 + ridge * 0.58, 0.0, 0.94);
    vec3 color = mix(blueColor.rgb, whiteColor.rgb, whiteMix);

    // Keep the shadow dim while preserving the same moving pattern.
    float shade = clamp(max(max(baseColor.r, baseColor.g), baseColor.b), 0.25, 1.0);
    result = vec4(color * shade, alpha * baseColor.a * blueColor.a);
}
