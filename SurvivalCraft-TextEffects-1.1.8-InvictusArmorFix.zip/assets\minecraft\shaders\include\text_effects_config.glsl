#define TEXT_EFFECT(r, g, b) return true; case ((uint(r/4) << 16) | (uint(g/4) << 8) | (uint(b/4))):

TEXT_EFFECT(200, 190, 0) { // Secret Dev Bouncy #c8be00
    apply_animated_gradient_2(rgb(0, 255, 171), rgb(0, 207, 255));
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 190, 10) { // Manager #c8be0a
   apply_animated_gradient_2(rgb(178, 0, 0), rgb(255, 63, 40));
   textData.shouldScale = true;
}

TEXT_EFFECT(200, 190, 5) { // Rainbow (For Rainbow Cosmetic) #c8be05
    apply_rainbow();
}

TEXT_EFFECT(200, 190, 16) { // STARFALL (#c8be10)
    apply_animated_gradient_3_smoother(rgb(90, 130, 255), rgb(150, 180, 255), rgb(220, 230, 255), 1.0);
    apply_starlight_3_smoother(rgb(255, 255, 255), rgb(255, 240, 180), rgb(180, 220, 255), 1.0, 0.5, 1.0, 0.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 190, 20) { // CORRUPTED (#c8be14)
    apply_animated_gradient_2(rgb(120, 255, 140), rgb(40, 220, 120));
    apply_glitch(0.4, 1.0, 0.5);
}

TEXT_EFFECT(200, 190, 24) { // QUICKSILVER (#c8be18)
    apply_metalic(rgb(235, 240, 250), rgb(140, 150, 170));
    apply_shimmer(0.5, 0.7);
}

TEXT_EFFECT(200, 190, 28) { // WILDFIRE (#c8be1c)
    apply_animated_gradient_3(rgb(255, 200, 80), rgb(255, 140, 40), rgb(255, 90, 30));
    apply_fire();
}

TEXT_EFFECT(200, 190, 32) { // BOUNCY_CASTLE (#c8be20)
    apply_iterating_movement(0.35, 1.5);
    apply_animated_gradient_3(rgb(255, 122, 200), rgb(122, 220, 255), rgb(255, 224, 90));
}

TEXT_EFFECT(200, 190, 36) { // EARTHQUAKE (#c8be24)
    apply_shaking_movement();
    apply_animated_gradient_2(rgb(255, 170, 80), rgb(255, 210, 120));
}

TEXT_EFFECT(200, 190, 40) { // JACKPOT (#c8be28)
    apply_animated_character_cycle_4(rgb(255, 215, 0), rgb(255, 85, 85), rgb(85, 255, 136), rgb(85, 153, 255), 2.0, 3.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 190, 44) { // DISCO_FEVER (#c8be2c)
    apply_crazy_spectrum_rainbow(1.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 190, 48) { // DAYDREAM (#c8be30)
    apply_waving_movement(0.4, 1.2);
    apply_pastel_rainbow();
}

TEXT_EFFECT(200, 190, 60) { // TALON (#c8be3c)
    apply_animated_gradient_3(rgb(255, 246, 168), rgb(255, 210, 26), rgb(255, 227, 77));
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 190, 52) { // HEARTBEAT (#c8be34)
    apply_animated_gradient_2(rgb(255, 135, 175), rgb(255, 60, 120));
    apply_fade(rgb(255, 30, 90), 0.35);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 190, 56) { // ELDFJALL (#c8be38) - volcano colors smoothly morphing into iceland flag colors, 6s loop
    float eldfjallTime = fract(GameTime * 200.0);
    float flagWeight = smoothstep(0.38, 0.5, eldfjallTime) * (1.0 - smoothstep(0.88, 1.0, eldfjallTime));

    apply_fractal_4(rgb(200, 60, 30), rgb(255, 110, 40), rgb(255, 170, 60), rgb(255, 220, 120), 0.012);
    vec3 eldfjallVolcano = textData.color.rgb;

    apply_animated_gradient_4_smoother(rgb(24, 100, 190), rgb(255, 255, 255), rgb(220, 30, 53), rgb(255, 255, 255), 1.25);
    vec3 eldfjallFlag = textData.color.rgb;

    textData.color.rgb = mix(eldfjallVolcano, eldfjallFlag, flagWeight);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 190, 64) { // TRIUMPH (#c8be40) - Survival Invictus crate, laurel gold with victory glints
    apply_animated_gradient_3_smoother(rgb(255, 241, 168), rgb(232, 181, 48), rgb(181, 64, 42), 0.9);
    apply_starlight_3_smoother(rgb(255, 255, 255), rgb(255, 241, 168), rgb(255, 205, 95), 1.0, 0.5, 1.0, 0.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 190, 68) { // ROYAL_FLUSH (#c8be44) - Survival Invictus crate, smoky crimson with molten gold dripping down
    apply_fractal_smoother_6(rgb(90, 6, 16), rgb(165, 14, 30), rgb(220, 30, 45), rgb(255, 72, 72), rgb(255, 150, 130), rgb(200, 32, 46), 0.7);
    apply_gloss(0.2, 0.8);
    apply_blood_drip(rgb(255, 215, 90), rgb(255, 245, 190), 1.0, 1.6, 1.0);
}

TEXT_EFFECT(200, 190, 72) { // UNCONQUERED (#c8be48) - Survival Invictus crate, white gold and crimson polished sweep
    apply_animated_gradient_4_smoother(rgb(255, 255, 255), rgb(255, 217, 90), rgb(200, 32, 46), rgb(255, 217, 90), 1.2);
    apply_gloss(0.25, 0.75);
    apply_shimmer(0.6, 0.6);
}

TEXT_EFFECT(200, 190, 76) { // GILDED_LAUREL (#c8be4c) - Survival Invictus crate, swaying bronze and gold leaves
    apply_waving_movement(0.25, 1.0, 0.6);
    apply_fractal_4(rgb(150, 110, 28), rgb(232, 181, 48), rgb(255, 241, 168), rgb(255, 212, 105), 0.01);
}

TEXT_EFFECT(200, 190, 80) { // HIGH_ROLLER (#c8be50) - Survival Invictus crate, letters flip like dealt cards
    apply_animated_character_cycle_3(rgb(200, 32, 46), rgb(240, 236, 225), rgb(70, 70, 80), 1.5, 2.5);
    apply_gloss(0.15, 0.8);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 190, 84) { // WILD_CARD (#c8be54) - Survival Invictus milestone, shuffling purple and gold with a card-trick glitch
    apply_animated_character_cycle_3(rgb(150, 70, 210), rgb(232, 181, 48), rgb(240, 236, 225), 2.0, 3.0);
    apply_glitch(0.12, 0.6, 0.15);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 190, 88) { // VICTORS_GOLD (#c8be58) - Survival Invictus milestone, struck gold bar with a white glint
    apply_metalic(rgb(255, 236, 150), rgb(196, 146, 24));
    apply_color_shimmer(rgb(255, 255, 255), 0.5, 0.8);
}

TEXT_EFFECT(200, 190, 92) { // ETERNAL_CHAMPION (#c8be5c) - Survival Invictus top milestone, rolling gold and crimson, starlit
    apply_waving_movement(0.3, 1.0, 0.5);
    apply_animated_gradient_5_smoother(rgb(255, 241, 168), rgb(232, 181, 48), rgb(220, 30, 45), rgb(140, 20, 24), rgb(232, 181, 48), 1.4);
    apply_starlight_4_smoother(rgb(255, 255, 255), rgb(255, 241, 168), rgb(255, 140, 120), rgb(255, 215, 90), 1.0, 0.5, 1.0, 0.5);
}

TEXT_EFFECT(200, 190, 96) { // JUDAISM (#c8be60) - Skyblock supporter custom 1/1, violet and pink smoke fading into crimson and sky blue, with a glint
    apply_fractal_smoother_combined_dual_6(
    rgb(174, 45, 243), rgb(145, 35, 175), rgb(195, 65, 210), rgb(235, 110, 225), rgb(255, 170, 240), rgb(255, 255, 255),
    rgb(182, 8, 16), rgb(220, 66, 186), rgb(205, 7, 126), rgb(70, 150, 250), rgb(140, 210, 255), rgb(255, 255, 255),
    1.0, 0.25, 30.0, 0.25, 0.5, 0.0, 0.0);
    apply_shimmer(0.5, 0.35);
    textData.shouldScale = true;
}
// AUTO GENERATED on 2026-11-14
TEXT_EFFECT(200, 200, 0) { // AMERICAN_HERO (#c8c800)
    apply_animated_gradient_3(rgb(248, 26, 26), rgb(255, 255, 255), rgb(15, 48, 238));
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 4) { // RAINBOW_GOD (#c8c804)
    apply_rainbow();
}

TEXT_EFFECT(200, 200, 8) { // PRISON_BREAK (#c8c808)
    apply_animated_gradient_3(rgb(253, 88, 169), rgb(50, 166, 231), rgb(217, 232, 107));
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 12) { // PHOENIX_ULTRA (#c8c80C)
    apply_animated_gradient_2(rgb(255, 0, 0), rgb(246, 179, 0));
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 16) { // WATERMELON_HEAVEN (#c8c810)
    apply_animated_gradient_3(rgb(223, 58, 23), rgb(92, 243, 140), rgb(252, 45, 53));
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 20) { // NORTHERN_SKIES (#c8c814)
    apply_animated_gradient_3(rgb(110, 210, 221), rgb(158, 102, 204), rgb(139, 242, 158));
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 24) { // WITCHS_LOVE (#c8c818)
    apply_animated_gradient_3(rgb(127, 255, 0), rgb(50, 205, 50), rgb(0, 100, 0));
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 28) { // ARTISTS_TALENT (#c8c81C)
    apply_animated_gradient_5(rgb(58, 80, 241), rgb(235, 52, 189), rgb(227, 220, 114), rgb(231, 255, 36), rgb(37, 207, 93));
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 32) { // CHRISTMAS_SPIRIT (#c8c820)
    apply_animated_gradient_7_smoother(rgb(255, 42, 38), rgb(255, 84, 84), rgb(255, 156, 156), rgb(255, 255, 255), rgb(159, 255, 159), rgb(55, 255, 55), rgb(15, 175, 15), 1.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 36) { // CANDY_CANE (#c8c824)
    apply_animated_gradient_7_smoother(rgb(232, 0, 46), rgb(255, 24, 68), rgb(255, 79, 111), rgb(255, 255, 255), rgb(255, 230, 235), rgb(255, 188, 201), rgb(255, 143, 170), 1.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 40) { // ARCTIC_BURST (#c8c828)
    apply_animated_gradient_5(rgb(224, 255, 255), rgb(176, 247, 255), rgb(115, 231, 255), rgb(44, 206, 255), rgb(0, 158, 255), 1.75);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 44) { // ELECTRO_NEON (#c8c82C)
    apply_animated_gradient_2(rgb(252, 0, 255), rgb(0, 219, 222));
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 48) { // BLOOMFLARE (#c8c830)
    apply_animated_gradient_3(rgb(255, 162, 0), rgb(255, 30, 151), rgb(255, 115, 0));
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 52) { // HORIZON_BURST (#c8c834)
    apply_animated_gradient_5(rgb(77, 166, 255), rgb(153, 204, 255), rgb(255, 217, 179), rgb(255, 178, 102), rgb(255, 122, 0));
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 56) { // HEART_THROB (#c8c838)
    apply_animated_gradient_5(rgb(255, 20, 147), rgb(255, 105, 180), rgb(255, 182, 193), rgb(255, 105, 180), rgb(255, 20, 147), 1.25);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 60) { // REAPER (#c8c83C)
    apply_animated_gradient_3(rgb(50, 50, 50), rgb(150, 150, 150), rgb(255, 255, 255));
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 64) { // COTTON_CANDY_CAMO (#c8c840)
    apply_fractal_5(rgb(255, 90, 201), rgb(255, 141, 218), rgb(255, 191, 240), rgb(168, 218, 255), rgb(114, 204, 255), 0.05);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 68) { // PARTY_LIGHTS (#c8c844)
    apply_fractal_3(rgb(255, 0, 128), rgb(255, 255, 0), rgb(0, 255, 255), 0.05);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 72) { // AURORA_BOREALIS (#c8c848)
    apply_crazy_spectrum_fractal_7(rgb(96, 30, 228), rgb(34, 242, 241), rgb(175, 77, 241), rgb(33, 205, 121), rgb(175, 77, 241), rgb(34, 242, 241), rgb(96, 30, 228), 2.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 76) { // EIGHTY_RIFF (#c8c84C)
    apply_animated_gradient_3_smoother(rgb(255, 50, 150), rgb(255, 180, 80), rgb(120, 80, 255), 1.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 80) { // CANDY_CORN (#c8c850)
    apply_animated_gradient_7_smoother(rgb(255, 69, 0), rgb(255, 140, 0), rgb(255, 215, 0), rgb(255, 250, 205), rgb(255, 215, 0), rgb(255, 140, 0), rgb(255, 69, 0), 1.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 84) { // TROPICAL_MINT (#c8c854)
    apply_animated_gradient_7_smoother(rgb(20, 200, 140), rgb(40, 230, 170), rgb(70, 250, 195), rgb(120, 255, 220), rgb(70, 250, 195), rgb(40, 230, 170), rgb(20, 200, 140), 1.65);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 88) { // CUPIDS_LOVE (#c8c858)
    apply_animated_gradient_7_smoother(rgb(178, 34, 34), rgb(220, 20, 60), rgb(255, 20, 147), rgb(255, 105, 180), rgb(255, 20, 147), rgb(220, 20, 60), rgb(178, 34, 34), 1.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 92) { // GLACIER_BLUE (#c8c85C)
    apply_animated_gradient_5_smoother(rgb(15, 95, 180), rgb(10, 135, 200), rgb(40, 185, 240), rgb(90, 165, 240), rgb(240, 245, 255), 1.65);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 96) { // SUPPORTER_PURPLE (#c8c860)
    apply_animated_gradient_7_smoother(rgb(72, 61, 139), rgb(123, 104, 238), rgb(147, 112, 219), rgb(216, 191, 216), rgb(147, 112, 219), rgb(123, 104, 238), rgb(72, 61, 139), 1.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 100) { // SUPPORTER_BLUE (#c8c864)
    apply_animated_gradient_7_smoother(rgb(100, 149, 237), rgb(135, 206, 250), rgb(135, 206, 235), rgb(176, 224, 230), rgb(135, 206, 235), rgb(135, 206, 250), rgb(100, 149, 237), 1.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 104) { // SUPPORTER_GOLD (#c8c868)
    apply_animated_gradient_7_smoother(rgb(204, 102, 0), rgb(255, 140, 0), rgb(255, 165, 0), rgb(255, 200, 124), rgb(255, 165, 0), rgb(255, 140, 0), rgb(204, 102, 0), 1.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 108) { // SUPPORTER_GREEN (#c8c86C)
    apply_animated_gradient_7_smoother(rgb(0, 120, 40), rgb(0, 180, 60), rgb(0, 210, 80), rgb(120, 255, 160), rgb(0, 210, 80), rgb(0, 180, 60), rgb(0, 120, 40), 1.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 112) { // CHROMATIC (#c8c870)
    apply_crazy_spectrum_fractal_7(rgb(131, 58, 180), rgb(180, 58, 150), rgb(220, 58, 100), rgb(253, 29, 29), rgb(253, 90, 37), rgb(253, 140, 41), rgb(252, 176, 69), 2.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 116) { // FIREWORK (#c8c874)
    apply_animated_gradient_7_smoother(rgb(0, 100, 255), rgb(100, 50, 255), rgb(200, 0, 200), rgb(255, 0, 100), rgb(255, 100, 0), rgb(255, 200, 0), rgb(255, 255, 0), 1.75);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 120) { // FIRE_AND_ICE (#c8c878)
    apply_camo_dual_3(
    rgb(255, 140, 0), rgb(255, 255, 180), rgb(232, 40, 0),
    rgb(54, 116, 233), rgb(255, 255, 255), rgb(140, 220, 255),
    1.5, 0.25, 65.0, 0.5, 0.5, 0.0, 0.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 124) { // MILK_CHOCOLATE (#c8c87C)
    apply_animated_gradient_7_smoother(rgb(181, 101, 29), rgb(205, 133, 63), rgb(222, 184, 135), rgb(255, 228, 196), rgb(222, 184, 135), rgb(205, 133, 63), rgb(181, 101, 29), 1.25);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 128) { // PURPLE_PULSE (#c8c880)
    apply_animated_gradient_7_smoother(rgb(180, 0, 255), rgb(210, 60, 255), rgb(240, 120, 255), rgb(255, 180, 255), rgb(240, 120, 255), rgb(210, 60, 255), rgb(180, 0, 255), 1.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 132) { // PERFECT_SKIES (#c8c884)
    apply_animated_gradient_5_smoother(rgb(108, 32, 248), rgb(52, 172, 172), rgb(110, 230, 230), rgb(52, 172, 172), rgb(108, 32, 248), 1.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 136) { // VAMPIRE_TWILIGHT (#c8c888)
    apply_animated_gradient_3_smoother(rgb(139, 0, 0), rgb(220, 20, 60), rgb(255, 69, 0), 1.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 140) { // ROYAL_BLOOD (#c8c88C)
    apply_animated_gradient_7_smoother(rgb(139, 0, 0), rgb(180, 20, 60), rgb(148, 60, 180), rgb(196, 113, 237), rgb(148, 60, 180), rgb(180, 20, 60), rgb(139, 0, 0), 1.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 144) { // EASTER (#c8c890)
      apply_fractal_7(rgb(255, 61, 113), rgb(255, 234, 0), rgb(0, 229, 255), rgb(134, 77, 255), rgb(0, 229, 255), rgb(255, 234, 0), rgb(255, 61, 113), 0.01);
      //apply_shimmer(0.05, 0.05);
      textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 148) { // SUPPORTER_RED (#c8c894)
    apply_animated_gradient_7_smoother(rgb(120, 0, 0), rgb(180, 0, 0), rgb(210, 0, 0), rgb(255, 120, 120), rgb(210, 0, 0), rgb(180, 0, 0), rgb(120, 0, 0), 1.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 152) { // ETHEREAL (#c8c898)
    apply_crazy_spectrum_fractal_4(rgb(230, 100, 150), rgb(190, 120, 230), rgb(150, 100, 220), rgb(100, 180, 230), 2.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 156) { // FRUIT_NINJA (#c8c89C)
    apply_animated_gradient_3_smoother(rgb(255, 59, 63), rgb(255, 247, 0), rgb(0, 255, 136), 1.75);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 160) { // LAVENDER_SPIRIT (#c8c8A0)
    apply_animated_gradient_3_smoother(rgb(152, 99, 231), rgb(219, 205, 240), rgb(228, 58, 150), 1.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 164) { // EMERALD_RADIANCE (#c8c8A4)
    apply_animated_gradient_7_smoother(rgb(10, 120, 10), rgb(15, 200, 15), rgb(10, 255, 130), rgb(150, 255, 200), rgb(10, 255, 130), rgb(15, 200, 15), rgb(10, 120, 10), 1.75);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 168) { // CHERRY_BLOOM (#c8c8A8)
    apply_camo_7(rgb(255, 140, 185), rgb(255, 110, 170), rgb(240, 80, 155), rgb(255, 160, 200), rgb(225, 70, 150), rgb(255, 125, 178), rgb(245, 95, 162), 50.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 172) { // SUPPORTER_PINK (#c8c8AC)
    apply_animated_gradient_7(rgb(220, 0, 100), rgb(255, 40, 140), rgb(200, 100, 255), rgb(255, 255, 255), rgb(230, 180, 255), rgb(255, 160, 200), rgb(255, 100, 160));
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 176) { // WORLDCUP26 (#c8c8B0)
          apply_fifa_fractal(1);
          apply_shimmer(0.5, 0.35);
          textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 180) { // SUGAR_RUSH (#c8c8B4)
    apply_fractal_smoother_7(rgb(255, 0, 127), rgb(255, 105, 180), rgb(173, 13, 29), rgb(255, 20, 147), rgb(255, 102, 204), rgb(61, 215, 239), rgb(0, 195, 255), 0.75);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 184) { // NEBULA (#c8c8B8)
    apply_fractal_smoother_combined_dual_6(
    rgb(35, 20, 90), rgb(70, 40, 135), rgb(110, 70, 180), rgb(155, 110, 220), rgb(205, 165, 245), rgb(245, 225, 255),
    rgb(15, 55, 110), rgb(45, 105, 170), rgb(49, 162, 254), rgb(42, 185, 246), rgb(123, 220, 246), rgb(255, 255, 255),
    1.0, 0.25, 30.0, 0.25, 0.5, 0.0, 0.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 188) { // HEATWAVE (#c8c8BC)
    apply_camo_vertical_7(rgb(209, 32, 16), rgb(220, 45, 8), rgb(245, 100, 15), rgb(255, 190, 30), rgb(245, 100, 15), rgb(220, 45, 8), rgb(209, 32, 16), 50.0);
    apply_shimmer(0.6, 0.45);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 192) { // PHANTOM (#c8c8C0)
    apply_camo_7(rgb(230, 235, 255), rgb(180, 190, 230), rgb(120, 130, 170), rgb(75, 80, 115), rgb(120, 130, 170), rgb(180, 190, 230), rgb(230, 235, 255), 20.0, 120.0);
    apply_shimmer(0.3, 0.35);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 196) { // CANDY_FLOSS (#c8c8C4)
    apply_animated_gradient_3_smoother(rgb(250, 232, 31), rgb(218, 100, 254), rgb(38, 232, 254), 1.75);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 204) { // BLUE_LAGOON (#c8c8CC)
    apply_animated_gradient_7_smoother(rgb(20, 130, 180), rgb(40, 160, 200), rgb(80, 190, 215), rgb(120, 210, 225), rgb(50, 170, 205), rgb(10, 100, 160), rgb(90, 195, 220), 1.25);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 208) { // VELVET_THUNDER (#c8c8D0)
    apply_animated_gradient_7_smoother(rgb(237, 30, 84), rgb(238, 12, 231), rgb(99, 26, 217), rgb(255, 67, 164), rgb(99, 26, 217), rgb(238, 12, 231), rgb(237, 30, 84), 1.25);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 212) { // AMETHYST_HAZE (#c8c8D4)
    apply_animated_gradient_4_smoother(rgb(255, 200, 235), rgb(220, 140, 255), rgb(180, 60, 255), rgb(255, 90, 200), 1.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 216) { // ROSE_GOLD (#c8c8D8)
    apply_animated_gradient_7_smoother(rgb(120, 60, 80), rgb(200, 110, 130), rgb(255, 150, 170), rgb(255, 220, 230), rgb(255, 150, 170), rgb(200, 110, 130), rgb(120, 60, 80), 1.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 220) { // PLUS_EXCLUSIVE (#c8c8DC)
    apply_animated_gradient_7_smoother(rgb(138, 90, 0), rgb(201, 138, 0), rgb(255, 170, 0), rgb(255, 221, 102), rgb(255, 255, 255), rgb(255, 221, 102), rgb(255, 170, 0), 1.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 224) { // PLUS_INSANE (#c8c8E0)
    apply_fractal_smoother_combined_dual_6(
    rgb(61, 43, 0), rgb(138, 90, 0), rgb(255, 170, 0), rgb(255, 221, 102), rgb(255, 244, 200), rgb(255, 255, 255),
    rgb(96, 106, 130), rgb(158, 170, 190), rgb(215, 225, 240), rgb(255, 255, 255), rgb(185, 232, 255), rgb(140, 210, 255),
    rgb(75, 0, 130), rgb(148, 0, 211), rgb(255, 0, 255), rgb(255, 105, 180), rgb(255, 215, 0), rgb(255, 255, 255),
    2.0, 0.25, 45.0, 0.25, 0.5, 1.0, 0.0);
    apply_shimmer(0.6, 0.45);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 228) { // LUCILE (#c8c8E4)
    apply_crazy_spectrum_fractal_7(rgb(255, 105, 180), rgb(235, 55, 120), rgb(210, 20, 60), rgb(180, 15, 15), rgb(150, 20, 60), rgb(190, 60, 120), rgb(230, 111, 155), 2.0);
    apply_shimmer(0.35, 0.35);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 200, 232) { // CROATIA (#c8c8E8)
    apply_crazy_spectrum_fractal_4(rgb(255, 0, 0), rgb(177, 177, 177), rgb(17, 136, 221), rgb(240, 170, 13), 2.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 124) { // CANDIDATE BLOOD_DEMON (#c8cc7c)
    apply_crazy_spectrum_fractal_6(rgb(40, 0, 8), rgb(112, 11, 24), rgb(200, 20, 40), rgb(255, 40, 75), rgb(255, 140, 110), rgb(150, 0, 30), 2.0);
    apply_glitch(0.18, 0.70, 0.2);
    apply_shimmer(0.4, 0.3);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 128) { // CANDIDATE WINTER_SOUL (#c8cc80)
    apply_crazy_spectrum_5(rgb(30, 60, 120), rgb(57, 123, 217), rgb(150, 220, 255), rgb(230, 250, 255), rgb(255, 255, 255), 1.0);
    apply_starlight_5_smoother(rgb(255, 255, 255), rgb(223, 246, 255), rgb(168, 220, 240), rgb(255, 255, 255), rgb(234, 250, 255), 18.0, 0.6, 2.5, 1.8);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 164) { // CANDIDATE FROZEN_HELL (#c8cca4)
    apply_fractal_smoother_combined_dual_5(rgb(180, 250, 255), rgb(65, 220, 255), rgb(25, 115, 220), rgb(90, 200, 255), rgb(160, 240, 255), rgb(255, 120, 35), rgb(220, 25, 15), rgb(145, 5, 5), rgb(255, 55, 15), rgb(245, 90, 25), 1.0, 0.25, 30.0, 0.25, 0.5, 0.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 168) { // CANDIDATE WITCHS_BREW (#c8cca8)
    apply_crazy_spectrum_fractal_5(rgb(18, 215, 45), rgb(70, 215, 65), rgb(130, 25, 215), rgb(180, 60, 215), rgb(8, 28, 12), 2.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 172) { // CANDIDATE BLOODY_ABYSS (#c8ccac)
    apply_crazy_spectrum_fractal_6(rgb(180, 21, 40), rgb(221, 41, 50), rgb(130, 1, 16), rgb(92, 94, 97), rgb(200, 210, 220), rgb(171, 162, 162), 2.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 176) { // CANDIDATE TRICK_OR_TREAT (#c8ccb0)
    apply_animated_gradient_5_smoother(rgb(255, 120, 20), rgb(255, 60, 140), rgb(170, 70, 255), rgb(255, 60, 140), rgb(255, 160, 40), 1.25);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 180) { // CANDIDATE TOMB_RAIDER (#c8ccb4)
    apply_animated_gradient_7_smoother(rgb(40, 25, 28), rgb(90, 45, 32), rgb(145, 75, 35), rgb(195, 115, 45), rgb(225, 160, 60), rgb(155, 55, 30), rgb(65, 28, 30), 1.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 184) { // CANDIDATE GHOST_VEIL (#c8ccb8)
    apply_animated_gradient_5_smoother(rgb(55, 55, 85), rgb(95, 100, 145), rgb(155, 160, 200), rgb(205, 205, 225), rgb(80, 75, 120), 1.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 156) { // CANDIDATE ETERNAL_FLAME (#c8cc9c)
    apply_animated_gradient_5_smoother(rgb(45, 0, 5), rgb(120, 5, 15), rgb(235, 45, 35), rgb(255, 105, 35), rgb(85, 0, 10), 1.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 160) { // CANDIDATE NIGHT_SPIRIT (#c8cca0)
    apply_animated_gradient_5_smoother(rgb(5, 35, 65), rgb(10, 100, 135), rgb(30, 210, 190), rgb(120, 255, 190), rgb(5, 75, 100), 1.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 252) { // CANDIDATE PUMPKIN_BLAZE (#c8ccfc)
    apply_crazy_spectrum_fractal_7(rgb(235, 125, 25), rgb(190, 40, 15), rgb(110, 22, 10), rgb(240, 150, 45), rgb(215, 75, 15), rgb(95, 28, 10), rgb(160, 50, 15), 2.0);
    apply_fire(rgb(255, 145, 25), rgb(190, 25, 15));
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 244) { // CANDIDATE MIDNIGHT_GHOUL (#c8ccf4)
    apply_crazy_spectrum_fractal_4(rgb(114, 122, 142), rgb(120, 158, 225), rgb(185, 192, 208), rgb(52, 82, 171), 2.0);
    apply_blood_drip(rgb(247, 6, 22), 1.25, 2.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 248) { // CANDIDATE PUMPKIN_MIST (#c8ccf8)
    apply_animated_gradient_7_smoother(rgb(180, 125, 25), rgb(235, 175, 55), rgb(255, 205, 95), rgb(230, 115, 25), rgb(195, 105, 45), rgb(175, 175, 180), rgb(215, 215, 220), 1.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 120) { // CANDIDATE GALAXY (#c8cc78)
    apply_crazy_spectrum_fractal_7(rgb(77, 35, 139), rgb(112, 64, 184), rgb(147, 88, 212), rgb(183, 122, 232), rgb(216, 184, 245), rgb(170, 118, 220), rgb(107, 72, 183), 1.2);
    apply_shimmer(0.18, 0.12);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 0) { // CANDIDATE TOXIC (#c8cc00)
    apply_fractal_smoother_7(rgb(163, 91, 240), rgb(74, 166, 245), rgb(34, 227, 106), rgb(255, 255, 255), rgb(220, 255, 210), rgb(170, 240, 160), rgb(120, 224, 140), 0.85);
    apply_shimmer(0.5, 0.35);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 4) { // CANDIDATE GAMMA (#c8cc04)
    apply_crazy_spectrum_fractal_7(rgb(163, 91, 240), rgb(110, 60, 255), rgb(74, 166, 245), rgb(40, 220, 235), rgb(34, 227, 106), rgb(150, 255, 90), rgb(210, 140, 255), 3.0);
    apply_shimmer(0.5, 0.35);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 8) { // CANDIDATE CHROME (#c8cc08)
    apply_metalic(rgb(235, 245, 255), rgb(70, 90, 120));
    apply_shimmer(0.75, 0.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 12) { // CANDIDATE ELECTRO_BURST (#c8cc0c)
    apply_crazy_spectrum_fractal_5(rgb(200, 45, 95), rgb(205, 125, 40), rgb(205, 190, 40), rgb(40, 185, 110), rgb(40, 150, 205), 4.0);
    apply_glitch(0.12, 1.5, 0.25);
    apply_glitch(0.75, 0.5, 0.07);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 16) { // CANDIDATE STARFALL (#c8cc10)
    apply_fractal_smoother_5(rgb(18, 10, 46), rgb(59, 30, 120), rgb(122, 59, 212), rgb(201, 160, 255), rgb(255, 255, 255), 0.6);
    apply_starlight_5(rgb(255, 255, 255), rgb(232, 208, 255), rgb(169, 123, 255), rgb(255, 255, 255), rgb(220, 200, 255), 20.0, 0.5, 3.0, 1.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 20) { // CANDIDATE EMBERSTORM (#c8cc14)
    apply_camo_7(rgb(255, 122, 24), rgb(255, 146, 40), rgb(255, 172, 64), rgb(255, 198, 104), rgb(255, 222, 150), rgb(255, 186, 84), rgb(255, 138, 34), 45.0);
    apply_fire(rgb(52, 8, 74), rgb(128, 44, 178));
}

TEXT_EFFECT(200, 204, 24) { // CANDIDATE NEON_ARCADE (#c8cc18)
    apply_animated_character_cycle_6(rgb(255, 47, 208), rgb(138, 47, 255), rgb(47, 208, 255), rgb(47, 255, 154), rgb(255, 233, 47), rgb(255, 107, 47), 1.0, 1.2);
    apply_glowing();
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 28) { // CANDIDATE VENOM (#c8cc1c)
    apply_crazy_spectrum_fractal_6(rgb(10, 26, 0), rgb(43, 92, 0), rgb(109, 227, 0), rgb(182, 255, 74), rgb(234, 255, 154), rgb(59, 165, 0), 1.6);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 32) { // CANDIDATE ABYSS (#c8cc20)
    apply_camo_vertical_6(rgb(2, 26, 38), rgb(4, 69, 92), rgb(10, 125, 148), rgb(19, 184, 196), rgb(124, 232, 236), rgb(255, 255, 255), 45.0);
    apply_color_shimmer(rgb(190, 255, 255), 0.55, 0.4);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 36) { // CANDIDATE BLOOD_MOON (#c8cc24)
    apply_camo_7(rgb(90, 6, 14), rgb(130, 8, 20), rgb(180, 12, 28), rgb(220, 20, 38), rgb(240, 40, 50), rgb(255, 80, 66), rgb(255, 120, 100), 45.0);
    apply_fire();
}

TEXT_EFFECT(200, 204, 40) { // CANDIDATE PRISM (#c8cc28)
    apply_crazy_spectrum_rainbow_fractal(2.0);
    apply_shimmer(0.55, 0.4);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 44) { // CANDIDATE MOSSAD (#c8cc2c)
    apply_crazy_spectrum_fractal_5(rgb(74, 85, 104), rgb(90, 15, 60), rgb(160, 30, 220), rgb(255, 45, 61), rgb(77, 250, 255), 2.0);
    apply_glitch(0.18, 0.70, 0.35);
    apply_glitch(0.1, 0.35, 0.25);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 48) { // CANDIDATE RETRO_SUNSET (#c8cc30)
    apply_camo_vertical_5(rgb(43, 10, 74), rgb(122, 31, 143), rgb(224, 53, 122), rgb(255, 138, 60), rgb(255, 217, 138), 40.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 52) { // CANDIDATE INKWELL (#c8cc34)
    apply_fractal_smoother_combined_dual_5_flat(rgb(5, 4, 10), rgb(26, 16, 48), rgb(61, 33, 112), rgb(122, 79, 212), rgb(201, 168, 255), rgb(255, 255, 255), rgb(232, 228, 245), rgb(201, 194, 224), rgb(255, 255, 255), rgb(245, 242, 255), rgb(5, 4, 10), rgb(26, 16, 48), rgb(61, 33, 112), rgb(122, 79, 212), rgb(201, 168, 255), 1.0, 0.25, 28.0, 0.5, 0.5, 0.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 56) { // CANDIDATE GLACIER (#c8cc38)
    apply_crazy_spectrum_5(rgb(10, 47, 69), rgb(27, 107, 138), rgb(92, 200, 224), rgb(194, 242, 255), rgb(255, 255, 255), 0.8);
    apply_starlight_5_smoother(rgb(255, 255, 255), rgb(223, 246, 255), rgb(168, 220, 240), rgb(255, 255, 255), rgb(234, 250, 255), 18.0, 0.6, 2.5, 1.8);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 88) { // CANDIDATE SAND_STORM (#c8cc58)
    apply_animated_character_cycle_7(rgb(120, 78, 26), rgb(168, 116, 42), rgb(214, 168, 78), rgb(250, 232, 176), rgb(240, 190, 110), rgb(206, 140, 60), rgb(150, 96, 34), 1.0, 1.4);
    apply_color_shimmer(rgb(255, 214, 140), 0.55, 0.4);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 92) { // CANDIDATE BLACK_PEARL (#c8cc5c)
    apply_camo_7(rgb(52, 56, 74), rgb(88, 94, 118), rgb(124, 130, 158), rgb(164, 170, 192), rgb(206, 212, 228), rgb(248, 248, 252), rgb(178, 152, 212), 45.0);
    apply_fire(rgb(105, 110, 138), rgb(242, 242, 252));
}

TEXT_EFFECT(200, 204, 100) { // CANDIDATE CORRUPTED (#c8cc64)
    apply_crazy_spectrum_fractal_7(rgb(163, 91, 240), rgb(253, 29, 29), rgb(74, 166, 245), rgb(253, 140, 41), rgb(34, 227, 106), rgb(180, 58, 150), rgb(252, 176, 69), 3.0);
    apply_glitch(0.12, 1.5, 0.12);
    apply_glitch(0.75, 0.5, 0.035);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 104) { // CANDIDATE STATIC_SURGE (#c8cc68)
    apply_crazy_spectrum_fractal_7(rgb(110, 60, 255), rgb(74, 166, 245), rgb(40, 220, 235), rgb(34, 227, 106), rgb(253, 90, 37), rgb(253, 29, 29), rgb(131, 58, 180), 2.5);
    apply_glitch(0.18, 0.70, 0.17);
    apply_glitch(0.1, 0.35, 0.12);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 108) { // CANDIDATE OVERCLOCK (#c8cc6c)
    apply_crazy_spectrum_fractal_5(rgb(163, 91, 240), rgb(34, 227, 106), rgb(253, 29, 29), rgb(252, 176, 69), rgb(40, 220, 235), 4.0);
    apply_glitch(0.12, 1.5, 0.12);
    apply_glitch(0.75, 0.5, 0.035);
    apply_shimmer(0.5, 0.35);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 112) { // CANDIDATE MALWARE (#c8cc70)
    apply_crazy_spectrum_fractal_6(rgb(131, 58, 180), rgb(220, 58, 100), rgb(253, 29, 29), rgb(253, 140, 41), rgb(34, 227, 106), rgb(40, 220, 235), 2.0);
    apply_glitch(0.2, 1.5, 0.17);
    apply_glitch(0.85, 0.4, 0.05);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 116) { // CANDIDATE HEXCODE (#c8cc74)
    apply_crazy_spectrum_fractal_7(rgb(253, 29, 29), rgb(163, 91, 240), rgb(74, 166, 245), rgb(255, 255, 255), rgb(34, 227, 106), rgb(252, 176, 69), rgb(180, 58, 150), 3.0);
    apply_glitch(0.12, 1.5, 0.12);
    apply_glitch(0.75, 0.5, 0.035);
    apply_shimmer(0.5, 0.35);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 132) { // CANDIDATE ASIIMOV (#c8cc84)
    apply_animated_gradient_5_smoother(rgb(84, 88, 96), rgb(170, 174, 182), rgb(255, 255, 255), rgb(255, 196, 140), rgb(255, 110, 0), 1.6);
    apply_glitch(0.12, 1.5, 0.25);
    apply_glitch(0.75, 0.5, 0.07);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 136) { // CANDIDATE ASIIMOV_FRACTAL (#c8cc88)
    apply_crazy_spectrum_fractal_6(rgb(84, 88, 96), rgb(255, 255, 255), rgb(255, 110, 0), rgb(140, 144, 152), rgb(240, 240, 245), rgb(255, 150, 40), 2.5);
    apply_glitch(0.12, 1.5, 0.12);
    apply_glitch(0.75, 0.5, 0.035);
    apply_shimmer(0.5, 0.35);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 140) { // CANDIDATE ASIIMOV_CHROME (#c8cc8c)
    apply_metalic(rgb(245, 245, 250), rgb(80, 84, 92));
    apply_color_shimmer(rgb(255, 120, 0), 0.6, 0.5);
    apply_glitch(0.18, 0.70, 0.35);
    apply_glitch(0.1, 0.35, 0.25);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 144) { // CANDIDATE RADIANT (#c8cc90)
    apply_animated_gradient_4_smoother(rgb(255, 255, 255), rgb(57, 255, 20), rgb(255, 255, 255), rgb(255, 50, 190), 1.6);
    apply_glitch(0.12, 1.5, 0.25);
    apply_glitch(0.75, 0.5, 0.07);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 148) { // CANDIDATE RADIANT_FRACTAL (#c8cc94)
    apply_crazy_spectrum_fractal_4(rgb(255, 255, 255), rgb(57, 255, 20), rgb(255, 255, 255), rgb(255, 50, 190), 3.0);
    apply_glitch(0.12, 1.5, 0.12);
    apply_glitch(0.75, 0.5, 0.035);
    apply_shimmer(0.5, 0.35);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 152) { // CANDIDATE RADIANT_NEON (#c8cc98)
    apply_animated_character_cycle_4(rgb(255, 255, 255), rgb(57, 255, 20), rgb(255, 255, 255), rgb(255, 50, 190), 1.0, 0.35);
    apply_glowing();
    apply_glitch(0.18, 0.70, 0.35);
    apply_glitch(0.1, 0.35, 0.25);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 96) { // CANDIDATE SERAPH (#c8cc60)
    apply_seraph();
}

TEXT_EFFECT(200, 204, 72) { // CANDIDATE AFTERGLOW (#c8cc48)
    apply_animated_gradient_7_smoother(rgb(27, 16, 70), rgb(122, 47, 160), rgb(255, 107, 74), rgb(255, 255, 255), rgb(255, 217, 160), rgb(255, 176, 122), rgb(232, 138, 155), 1.6);
    apply_shimmer(0.35, 0.25);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 76) { // CANDIDATE NIGHTSHADE (#c8cc4c)
    apply_animated_gradient_7_smoother(rgb(18, 0, 24), rgb(90, 20, 140), rgb(200, 60, 230), rgb(255, 255, 255), rgb(245, 205, 255), rgb(222, 160, 255), rgb(186, 110, 240), 1.8);
    apply_shimmer(0.35, 0.25);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 80) { // CANDIDATE OPAL (#c8cc50)
    apply_animated_gradient_7_smoother(rgb(255, 179, 217), rgb(179, 224, 255), rgb(179, 255, 217), rgb(255, 255, 255), rgb(255, 230, 242), rgb(230, 245, 255), rgb(240, 255, 247), 1.2);
    apply_shimmer(0.35, 0.25);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 84) { // CANDIDATE ACID_RAIN (#c8cc54)
    apply_animated_gradient_7_smoother(rgb(10, 26, 0), rgb(43, 92, 0), rgb(140, 255, 20), rgb(255, 255, 255), rgb(230, 255, 180), rgb(195, 255, 110), rgb(160, 240, 60), 2.0);
    apply_shimmer(0.35, 0.25);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 60) { // CANDIDATE SLIME_TOXIC (#c8cc3c)
    apply_animated_gradient_7_smoother(rgb(163, 91, 240), rgb(74, 166, 245), rgb(34, 227, 106), rgb(255, 255, 255), rgb(220, 255, 210), rgb(170, 240, 160), rgb(120, 224, 140), 2.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 64) { // CANDIDATE SLIME_BUBBLEGUM (#c8cc40)
    apply_animated_gradient_7_smoother(rgb(255, 110, 199), rgb(74, 166, 245), rgb(34, 227, 106), rgb(255, 255, 255), rgb(255, 224, 242), rgb(255, 184, 224), rgb(255, 150, 210), 2.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 68) { // CANDIDATE SLIME_AQUA (#c8cc44)
    apply_animated_gradient_7_smoother(rgb(58, 157, 255), rgb(34, 227, 106), rgb(20, 230, 200), rgb(255, 255, 255), rgb(220, 255, 246), rgb(168, 245, 230), rgb(110, 232, 210), 2.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 188) { // CANDIDATE OCEANIC_DEPTHS (#c8ccbc)
    apply_camo_vertical_6(rgb(30, 130, 210), rgb(45, 165, 235), rgb(85, 200, 245), rgb(150, 232, 255), rgb(70, 185, 240), rgb(40, 150, 225), 30.0);
    apply_waving_movement(0.4, 1.0, 0.4);
    apply_color_shimmer(rgb(210, 250, 255), 0.6, 0.35);
}

TEXT_EFFECT(200, 204, 192) { // CANDIDATE WATER_HAZARD (#c8ccc0)
    apply_crazy_spectrum_fractal_6(rgb(0, 160, 175), rgb(0, 205, 190), rgb(90, 240, 210), rgb(225, 255, 245), rgb(0, 225, 255), rgb(0, 135, 170), 1.4);
    apply_glitch(0.10, 0.55, 0.12);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 196) { // CANDIDATE GOLD_WAVES (#c8ccc4)
    apply_animated_gradient_6_smoother(rgb(255, 196, 50), rgb(255, 222, 115), rgb(255, 244, 190), rgb(40, 90, 210), rgb(255, 212, 85), rgb(255, 232, 145), 0.4);
    apply_waving_movement(0.15, 1.5);
}

TEXT_EFFECT(200, 204, 200) { // CANDIDATE DEV_BOG_GRAPHITE (#c8ccc8)
    apply_animated_gradient_3_smoother(rgb(76, 79, 87), rgb(124, 127, 135), rgb(186, 188, 194), 0.4);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 204) { // CANDIDATE DEV_BOG_FOG (#c8cccc)
    apply_fractal_smoother_3(rgb(76, 79, 87), rgb(124, 127, 135), rgb(186, 188, 194), 0.4);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 208) { // CANDIDATE DEV_BOG_GUNMETAL (#c8ccd0)
    apply_animated_gradient_3_smoother(rgb(76, 79, 87), rgb(124, 127, 135), rgb(186, 188, 194), 0.4);
    apply_gloss(0.15, 0.8);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 212) { // CANDIDATE DEV_BOG_FLINT (#c8ccd4)
    apply_animated_gradient_3_smoother(rgb(76, 79, 87), rgb(124, 127, 135), rgb(186, 188, 194), 0.4);
    apply_shimmer(0.3, 0.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 216) { // CANDIDATE DEV_BOG_NIGHTFALL (#c8ccd8)
    apply_starlight_3_smoother(rgb(76, 79, 87), rgb(124, 127, 135), rgb(186, 188, 194), 6.0, 0.8, 0.4, 2.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 220) { // CANDIDATE DEV_APLOSH_ROSEWOOD (#c8ccdc)
    apply_animated_gradient_3_smoother(rgb(94, 58, 76), rgb(156, 102, 128), rgb(204, 159, 181), 0.4);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 224) { // CANDIDATE DEV_APLOSH_ROSEMIST (#c8cce0)
    apply_fractal_smoother_3(rgb(94, 58, 76), rgb(156, 102, 128), rgb(204, 159, 181), 0.4);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 228) { // CANDIDATE DEV_APLOSH_ROSE_GOLD (#c8cce4)
    apply_animated_gradient_3_smoother(rgb(94, 58, 76), rgb(156, 102, 128), rgb(204, 159, 181), 0.4);
    apply_gloss(0.15, 0.8);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 232) { // CANDIDATE DEV_APLOSH_QUARTZ (#c8cce8)
    apply_animated_gradient_3_smoother(rgb(94, 58, 76), rgb(156, 102, 128), rgb(204, 159, 181), 0.4);
    apply_shimmer(0.3, 0.5);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 236) { // CANDIDATE DEV_APLOSH_DUSK_ROSE (#c8ccec)
    apply_starlight_3_smoother(rgb(94, 58, 76), rgb(156, 102, 128), rgb(204, 159, 181), 6.0, 0.8, 0.4, 2.0);
    textData.shouldScale = true;
}

TEXT_EFFECT(200, 204, 240) { // CANDIDATE ECLIPSE (#c8ccf0)
    apply_animated_gradient_5_smoother(rgb(224, 16, 46), rgb(143, 18, 48), rgb(107, 107, 118), rgb(242, 246, 255), rgb(169, 191, 230), 1.6);
    apply_color_shimmer(rgb(242, 246, 255), 0.5, 0.35);
    textData.shouldScale = true;
}
