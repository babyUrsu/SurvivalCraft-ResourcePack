#version 330
#extension GL_ARB_separate_shader_objects : require
#define FSH
#define RENDERTYPE_TEXT
#define IS_1_21_6

#define VCTFX_NO_QUAD_SCALE

#if defined(IS_SEE_THROUGH) || defined(IS_GRAYSCALE)
#define VCTFX_DISABLED
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#define VCTFX_WORLD_FOG
#include <minecraft:fog.glsl>
#endif

#define VCTFX_NO_FOG

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#ifdef VCTFX_WORLD_FOG
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) in vec4 baseColor;
layout(location = 5) in vec4 lightColor;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 outColor;
#endif

#define fragColor vctfx_fragColor
vec4 fragColor;

#ifndef VCTFX_DISABLED
#include <spheya_packs_impl.glsl>
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #ifdef VCTFX_WORLD_FOG

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

void writeColor(vec4 color) {
    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    outColor = calculateFinalColor(color);
    #endif
}

void main() {
#ifndef VCTFX_DISABLED
    if(applySpheyaPacks()) {
        writeColor(fragColor);
        return;
    }
#endif

#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

    vec4 color = texColor * vertexColor * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }

    writeColor(color);
}
