#version 330
#define VSH
#define RENDERTYPE_TEXT
#define IS_1_21_6

#define VCTFX_NO_QUAD_SCALE

#if defined(IS_SEE_THROUGH) || defined(IS_GRAYSCALE)
#define VCTFX_DISABLED
#endif

#if defined(IS_GUI) || defined(IS_SEE_THROUGH)
#define VCTFX_NO_FOG
#endif

#ifndef VCTFX_NO_FOG
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#ifndef VCTFX_NO_FOG
in ivec2 UV2;
#endif

uniform sampler2D Sampler0;
#ifndef VCTFX_NO_FOG
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;
out vec4 baseColor;
out vec4 lightColor;

#ifndef VCTFX_DISABLED
#moj_import <spheya_packs_impl.glsl>
#endif

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    baseColor = Color;

#ifndef VCTFX_NO_FOG
    lightColor = sample_lightmap(Sampler2, UV2);
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
#else
    lightColor = vec4(1.0);
#endif

    vertexColor = baseColor * lightColor;
    texCoord0 = UV0;

#ifndef VCTFX_DISABLED
    if(applySpheyaPacks()) return;
#endif
}
