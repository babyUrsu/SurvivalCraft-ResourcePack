#version 330
#define FSH
#define RENDERTYPE_TEXT
#define IS_1_21_6

#define VCTFX_NO_QUAD_SCALE

#if defined(IS_SEE_THROUGH) || defined(IS_GRAYSCALE)
#define VCTFX_DISABLED
#endif

#if defined(IS_GUI) || defined(IS_SEE_THROUGH)
#define VCTFX_NO_FOG
#endif

#ifndef VCTFX_NO_FOG
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

#ifndef VCTFX_NO_FOG
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;
in vec4 baseColor;
in vec4 lightColor;

out vec4 fragColor;

#ifndef VCTFX_DISABLED
#moj_import <spheya_packs_impl.glsl>
#endif

void main() {
#ifndef VCTFX_DISABLED
    if(applySpheyaPacks()) return;
#endif

#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * vertexColor;
#else
    vec4 color = texColor * vertexColor * ColorModulator;
#endif

    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
